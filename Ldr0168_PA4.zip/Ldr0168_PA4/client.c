//Luis Reyes CSCE3530 EUID:ldr0168
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/time.h>

int main (int argc, char **argv)
{
    int sockfd, portnum;
    char emailfile [1024];
    char recpfile [1024];
    char hostname[2048];
    struct sockaddr_in servaddr;
    struct hostent *server;
  
    
      //user prompts
        printf("SMTP Server: ");
        scanf(" %s", hostname);
        printf("Port Number: ");
        scanf("%d", &portnum);
     

  // server name
  server = gethostbyname(hostname);
  //creating socket
  sockfd = socket(AF_INET, SOCK_STREAM, 0);
  bzero(&servaddr, sizeof(servaddr));
  servaddr.sin_family = AF_INET;
  memcpy((char*)&servaddr.sin_addr.s_addr, (char*)server->h_addr, server->h_length);
  //the port number
  servaddr.sin_port = htons(portnum);

  /* Connect to the server */
  connect(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr));

   //loops until the user enters "quit" 
  while(1){


    printf("Email text file: ");
    scanf(" %s", emailfile);
    //if emailfile is  "quit" then close otherwise loop the program
    if(strcmp(emailfile, "quit") == 0)
        {
           char qresponse[2048];
         char quitCommand[]= "QUIT\r\n";
          write(sockfd, quitCommand, strlen(quitCommand));
          //response for quit command
          memset(qresponse, 0, sizeof(qresponse));
          read(sockfd, qresponse, sizeof(qresponse)-1);
          printf(" Response: %s\n", qresponse);
          close(sockfd);
           break;
        } 
    //recpients file
    printf("Recipient text file: " );
    scanf(" %s", recpfile);
  
    //Reading connection response
    char response[2048];
    memset(response, 0, sizeof(response));
    read(sockfd, response, sizeof(response));
  
  //response to the connection
   printf("Response: %s\n", response);
   

//ehlo command
 char ehloCommand[]= "EHLO\n";
  write(sockfd,ehloCommand , strlen(ehloCommand));
  //sleeps for 1 second
  sleep(1);
  //reponse for ehlo
  memset(response, 0, sizeof(response));
  read(sockfd, response, sizeof(response)-1);
  printf(" Response: %s\n", response);

  //AUTH LOGIN COMMAND
  char authCommand[]= "AUTH LOGIN\n";
  write(sockfd,authCommand , strlen(authCommand));
  
  //sleeps for 1 second
  sleep(1);
  //response for auth login
  memset(response, 0, sizeof(response));
  read(sockfd, response, sizeof(response)-1);
  printf("Response: %s\n", response);

  //username 
  char userName64[1024];
  printf("Username: ");
  scanf("%s", userName64);
  strcat(userName64, "\r\n" );
  write(sockfd, userName64, strlen(userName64));
  
  //sleeps for 1 second
  sleep(1);
  memset(response, 0, sizeof(response));
  read(sockfd, response, sizeof(response)-1);
  printf("Response: %s\n", response);
    
  //if the username is wrong then exit
  if(strstr(response,"334")==NULL)
  {
   close(sockfd);
    exit(EXIT_FAILURE);
  }
 
  //password
  char password64[1024];
  printf("Password: ");
  scanf("%s", password64);
  strcat(password64, "\r\n" );
  write(sockfd, password64, strlen(password64));

  //sleeps for 1 second
  sleep(1);
  //response for password
  memset(response, 0, sizeof(response));
  read(sockfd, response, sizeof(response)-1);
  printf("Response: %s\n", response);
    
  //if the response is not 334, then the password is wrong.exit
   if(strstr(response,"235")==NULL)
   {
     close(sockfd);
       exit(EXIT_FAILURE);
   }

  //Sender's email being found
  //input text file will be read
  FILE *emailFile= fopen(emailfile, "r");
  char email[1024];
  char line[1024];
  while(fgets(line, sizeof(line), emailFile))
    {
      //looks for the email that is in < >
      char *start = strchr(line, '<');
      char *end = strchr(line, '>');
      // scans for the email address
      sscanf(line, "FROM: %s", email);
      // the length of the email address between < >
      size_t length = end - start - 1;
      strncpy(email, start + 1, length);
      email[length] = '\0';
      break;
    }
  //closes the file 
  fclose(emailFile);
  //sender's email address
  printf("Sender's email address: %s\n", email);
    
  //MAIL From command
  char mailCommand[2048];
  snprintf(mailCommand, sizeof(mailCommand), "MAIL FROM: <%s>\r\n", email);
  write(sockfd, mailCommand, strlen(mailCommand));
  // response for mail from
  sleep(1);
  memset(response, 0, sizeof(response));
  read(sockfd, response, sizeof(response)-1);
  printf("Response: %s\n", response);
  
//Read the recipients.txt file 
  //RPCT will take the emails 
    FILE *recpFile= fopen(recpfile, "r");
    char recp[2048];
    while(fgets(recp, sizeof(recp), recpFile)!= NULL)
      {
        //remove the newline character from the end of the line
        // do not remove this line
       recp[strcspn(recp, "\n")] = '\0';

        printf("Recipient email address: %s\n", recp);

        //RCPT TO command
       char rcptCommand[4096];
        snprintf(rcptCommand, sizeof(rcptCommand), "RCPT TO: %s\r\n", recp);
        write(sockfd, rcptCommand, strlen(rcptCommand));

        //sleep
        sleep(1);
        //response for RCPT TO
        memset(response, 0, sizeof(response));
        read(sockfd, response, sizeof(response)-1);
        printf("Response: %s\n", response);
        
      }
    
    fclose(recpFile);

    //DATA command
    char dataCommand[]= "DATA\r\n";
    write(sockfd, dataCommand, strlen(dataCommand));
  
    sleep(1);
    //initial response to DATA connection
    memset(response, 0, sizeof(response));
    read(sockfd, response, sizeof(response)-1);
    printf("Response: %s\n", response);

    
    //input text file will be opened
    FILE *email_File= fopen(emailfile, "r");

  // reads the email file and saves the contents to a string buffer
   char line_buffer[1024];
   char email_buffer[16000]={0};
    //reads the email file line by line into the buffer
    while(fgets(line_buffer, sizeof(line_buffer), email_File)!= NULL)
      {
      
        strcat(email_buffer, line_buffer);
      
       
      }
    printf("%s", email_buffer);
    //writes the email buffer to the socket
    write(sockfd, email_buffer, strlen(email_buffer));
    //response to the DATA command
      memset(response, 0, sizeof(response));
      read(sockfd, response, sizeof(response)-1);
      printf("Response: %s\n", response);
        fclose(email_File);

    
  }

  
    return 0;

}